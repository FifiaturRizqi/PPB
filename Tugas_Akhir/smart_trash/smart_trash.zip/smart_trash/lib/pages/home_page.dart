import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:smart_trash/services/history_service.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:image/image.dart' as img;
import '../models/waste_classification_history.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:smart_trash/services/point_service.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  File? _image;
  bool _isLoading = false;
  Map<String, dynamic>? _classificationResult;
  final picker = ImagePicker();
  Interpreter? _interpreter;

  static final Map<String, Map<String, String>> wasteInfo = {
    'battery_waste': {
      'kategori': 'Limbah Baterai',
      'deskripsi':
          'Baterai bekas dan komponen elektronik yang mengandung bahan berbahaya.',
      'penanganan':
          'Harus dikumpulkan di tempat khusus dan dikirim ke fasilitas daur ulang baterai.'
    },
    'food_waste': {
      'kategori': 'Limbah Makanan',
      'deskripsi': 'Sisa makanan dan bahan organik yang dapat terurai.',
      'penanganan': 'Dapat dikompos atau diolah menjadi pupuk organik.'
    },
    'glassbrown_waste': {
      'kategori': 'Limbah Kaca Coklat',
      'deskripsi': 'Botol dan wadah kaca berwarna coklat.',
      'penanganan': 'Dapat didaur ulang menjadi produk kaca baru.'
    },
    'cardboard_waste': {
      'kategori': 'Limbah Kardus',
      'deskripsi': 'Kardus dan kemasan dari bahan karton.',
      'penanganan': 'Dapat didaur ulang menjadi kertas atau kardus baru.'
    },
    'clothes_waste': {
      'kategori': 'Limbah Pakaian',
      'deskripsi': 'Pakaian bekas yang sudah tidak terpakai.',
      'penanganan':
          'Dapat disumbangkan atau didaur ulang menjadi produk tekstil baru.'
    },
    'greenglass_waste': {
      'kategori': 'Limbah Kaca Hijau',
      'deskripsi': 'Botol dan wadah kaca berwarna hijau.',
      'penanganan': 'Dapat didaur ulang menjadi produk kaca baru.'
    },
    'metal_waste': {
      'kategori': 'Limbah Logam',
      'deskripsi': 'Kaleng, peralatan logam, dan bahan logam lainnya.',
      'penanganan': 'Dapat didaur ulang menjadi produk logam baru.'
    },
    'paper_waste': {
      'kategori': 'Limbah Kertas',
      'deskripsi': 'Kertas bekas, koran, dan bahan kertas lainnya.',
      'penanganan': 'Dapat didaur ulang menjadi kertas baru.'
    },
    'plastic_waste': {
      'kategori': 'Limbah Plastik',
      'deskripsi': 'Botol plastik, kemasan, dan bahan plastik lainnya.',
      'penanganan': 'Dapat didaur ulang menjadi produk plastik baru.'
    },
    'residual_waste': {
      'kategori': 'Limbah Residu',
      'deskripsi': 'Sampah yang tidak dapat didaur ulang atau dikompos.',
      'penanganan': 'Dibuang ke TPA dengan penanganan khusus.'
    },
    'footwear_waste': {
      'kategori': 'Limbah Alas Kaki',
      'deskripsi': 'Sepatu dan sandal bekas.',
      'penanganan':
          'Dapat didaur ulang atau disumbangkan jika masih layak pakai.'
    },
    'whiteglass_waste': {
      'kategori': 'Limbah Kaca Putih',
      'deskripsi': 'Botol dan wadah kaca bening/putih.',
      'penanganan': 'Dapat didaur ulang menjadi produk kaca baru.'
    }
  };

  @override
  void initState() {
    super.initState();
    _initializeModel();
  }

  @override
  void dispose() {
    _interpreter?.close();
    super.dispose();
  }

  Future<void> _initializeModel() async {
    try {
      final options = InterpreterOptions()..threads = 4;
      _interpreter = await Interpreter.fromAsset(
        'assets/model_unquant.tflite',
        options: options,
      );
      debugPrint('Model loaded successfully');
    } catch (e) {
      debugPrint('Error loading model: $e');
      _showError('Failed to load model. Please restart the app.');
    }
  }

  Future<void> _saveToHistory(
      String label, double confidence, String imagePath) async {
    final user = FirebaseAuth.instance.currentUser;
    final HistoryService _historyService = HistoryService();
    final PointService _pointService = PointService();

    if (user == null) return;

    final historyItem = WasteClassificationHistory(
      userId: user.uid,
      label: label,
      confidence: confidence,
      imagePath: imagePath,
      timestamp: DateTime.now(),
    );

    await _historyService.saveHistory(historyItem);
    await _pointService.addPoints(500); // Add points for classification
  }

  Future<void> getImage() async {
    try {
      setState(() => _isLoading = true);

      final pickedFile = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 85,
        maxWidth: 1024,
        maxHeight: 1024,
      );

      if (pickedFile != null) {
        setState(() {
          _image = File(pickedFile.path);
          _classificationResult = null;
        });
        await classifyImage(_image!);
      }
    } catch (e) {
      debugPrint('Error picking image: $e');
      _showError('Failed to pick image. Please try again.');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> classifyImage(File image) async {
    if (_interpreter == null) {
      _showError('Model not initialized');
      return;
    }

    try {
      final imageBytes = await image.readAsBytes();
      final imageData = img.decodeImage(imageBytes);

      if (imageData == null) {
        throw Exception('Failed to decode image');
      }

      final resizedImage = img.copyResize(
        imageData,
        width: 224,
        height: 224,
        interpolation: img.Interpolation.linear,
      );

      final input = List.generate(
        1,
        (_) => List.generate(
          224,
          (y) => List.generate(
            224,
            (x) => List.generate(3, (c) {
              final pixel = resizedImage.getPixel(x, y);
              return c == 0
                  ? pixel.r / 255.0
                  : c == 1
                      ? pixel.g / 255.0
                      : pixel.b / 255.0;
            }),
          ),
        ),
      );

      final output = List.filled(1, List<double>.filled(12, 0));
      _interpreter!.run(input, output);

      final scores = output[0];
      final maxScore = scores.reduce((a, b) => a > b ? a : b);
      final maxIndex = scores.indexOf(maxScore);

      const double confidenceThreshold = 0.6;

      if (maxScore >= confidenceThreshold) {
        final label = getLabelName(maxIndex);
        setState(() {
          _classificationResult = {
            'label': label,
            'confidence': maxScore,
          };
        });
        // Save to history
        await _saveToHistory(label, maxScore, image.path);
      } else {
        setState(() {
          _classificationResult = null;
        });
        _showError(
            'Tingkat kepercayaan terlalu rendah. Silakan coba gambar lain.');
      }
    } catch (e) {
      debugPrint('Error during classification: $e');
      _showError('Failed to classify image. Please try again.');
    }
  }

  String getLabelName(int index) {
    const labels = [
      'battery_waste',
      'food_waste',
      'glassbrown_waste',
      'cardboard_waste',
      'clothes_waste',
      'greenglass_waste',
      'metal_waste',
      'paper_waste',
      'plastic_waste',
      'residual_waste',
      'footwear_waste',
      'whiteglass_waste',
    ];
    return index >= 0 && index < labels.length ? labels[index] : 'unknown';
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        title: const Text(
          'Smart Trash Classification',
          style: TextStyle(
            color: Colors.green,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.white, Color(0xFFF5F5F5)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Image Preview Container
                Container(
                  height: 350,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: _isLoading
                        ? const Center(
                            child: CircularProgressIndicator(
                              color: Colors.green,
                            ),
                          )
                        : _image != null
                            ? Stack(
                                fit: StackFit.expand,
                                children: [
                                  Image.file(_image!, fit: BoxFit.cover),
                                  Positioned(
                                    right: 12,
                                    top: 12,
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Colors.black.withOpacity(0.6),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: IconButton(
                                        icon: const Icon(
                                          Icons.refresh,
                                          color: Colors.white,
                                        ),
                                        onPressed: getImage,
                                      ),
                                    ),
                                  ),
                                ],
                              )
                            : Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.add_photo_alternate_outlined,
                                    size: 80,
                                    color: Colors.grey[400],
                                  ),
                                  const SizedBox(height: 16),
                                  Text(
                                    'Tambahkan Foto Sampah',
                                    style: TextStyle(
                                      color: Colors.grey[600],
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                  ),
                ),

                const SizedBox(height: 24),

                // Upload Button
                if (_image == null)
                  ElevatedButton(
                    onPressed: _isLoading ? null : getImage,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 2,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.camera_alt_outlined),
                        SizedBox(width: 12),
                        Text(
                          'Ambil Gambar',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),

                if (_classificationResult != null) ...[
                  const SizedBox(height: 24),
                  _buildClassificationResult(),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildClassificationResult() {
    final label = _classificationResult!['label'];
    final confidence = _classificationResult!['confidence'];
    final info = wasteInfo[label];

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with confidence score
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Hasil Klasifikasi',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${(confidence * 100).toStringAsFixed(1)}%',
                  style: const TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Waste Type
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              label.replaceAll('_', ' ').toUpperCase(),
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Details
          _buildInfoRowNew('Kategori', info?['kategori'] ?? 'Tidak diketahui'),
          _buildInfoRowNew(
              'Deskripsi', info?['deskripsi'] ?? 'Tidak ada deskripsi'),
          _buildInfoRowNew('Penanganan',
              info?['penanganan'] ?? 'Tidak ada informasi penanganan',
              isLast: true),
        ],
      ),
    );
  }

  Widget _buildInfoRowNew(String title, String content, {bool isLast = false}) {
    return Container(
      margin: EdgeInsets.only(bottom: isLast ? 0 : 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 6),
          Text(
            content,
            style: const TextStyle(
              fontSize: 16,
              color: Colors.black87,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}
