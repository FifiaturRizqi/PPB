class WasteClassificationHistory {
  final String userId;  // Tambahan field untuk user ID
  final String label;
  final double confidence;
  final String imagePath;
  final DateTime timestamp;

  WasteClassificationHistory({
    required this.userId,
    required this.label,
    required this.confidence,
    required this.imagePath,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'label': label,
      'confidence': confidence,
      'imagePath': imagePath,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  factory WasteClassificationHistory.fromMap(Map<String, dynamic> map) {
    return WasteClassificationHistory(
      userId: map['userId'],
      label: map['label'],
      confidence: map['confidence'],
      imagePath: map['imagePath'],
      timestamp: DateTime.parse(map['timestamp']),
    );
  }
}