import 'package:cloud_firestore/cloud_firestore.dart';

class ClassificationHistory {
  final String id;
  final String imageUrl;
  final String wasteType;
  final DateTime timestamp;
  final int points;

  ClassificationHistory({
    required this.id,
    required this.imageUrl,
    required this.wasteType,
    required this.timestamp,
    required this.points,
  });


  factory ClassificationHistory.fromMap(Map<String, dynamic> map, String documentId) {
    return ClassificationHistory(
      id: documentId, 
      imageUrl: map['imageUrl'] ?? '',
      wasteType: map['wasteType'] ?? '',
      timestamp: (map['timestamp'] as Timestamp).toDate(), 
      points: map['points'] ?? 10,
    );
  }


  Map<String, dynamic> toMap() {
    return {
      'imageUrl': imageUrl,
      'wasteType': wasteType,
      'timestamp': timestamp,
      'points': points,
    };
  }
}
