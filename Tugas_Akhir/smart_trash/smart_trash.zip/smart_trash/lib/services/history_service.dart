import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../models/waste_classification_history.dart';

class HistoryService {
  static const String _historyKey = 'waste_history';
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Mendapatkan key spesifik untuk user tertentu
  String _getUserHistoryKey(String userId) {
    return '${_historyKey}_$userId';
  }

  // Menyimpan history
  Future<void> saveHistory(WasteClassificationHistory history) async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;

      final prefs = await SharedPreferences.getInstance();
      final historyKey = _getUserHistoryKey(user.uid);
      final historyJson = prefs.getStringList(historyKey) ?? [];
      
      historyJson.insert(0, json.encode(history.toMap()));
      
      // Batasi history maksimal 50 item per user
      if (historyJson.length > 50) {
        historyJson.removeLast();
      }
      
      await prefs.setStringList(historyKey, historyJson);
    } catch (e) {
      debugPrint('Error saving history: $e');
    }
  }

  // Mengambil history untuk user yang sedang login
  Future<List<WasteClassificationHistory>> getHistory() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return [];

      final prefs = await SharedPreferences.getInstance();
      final historyKey = _getUserHistoryKey(user.uid);
      final historyJson = prefs.getStringList(historyKey) ?? [];
      
      return historyJson
          .map((item) => WasteClassificationHistory.fromMap(json.decode(item)))
          .toList();
    } catch (e) {
      debugPrint('Error loading history: $e');
      return [];
    }
  }

  // Menghapus semua history untuk user tertentu
  Future<void> clearHistory() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return;

      final prefs = await SharedPreferences.getInstance();
      final historyKey = _getUserHistoryKey(user.uid);
      await prefs.remove(historyKey);
    } catch (e) {
      debugPrint('Error clearing history: $e');
    }
  }
}
