import 'dart:math';
import 'package:smart_trash/models/reward.dart';

class RewardService {
  String _generateVoucherCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final random = Random();
    return List.generate(8, (index) => chars[random.nextInt(chars.length)]).join();
  }

  Future<List<Reward>> getAvailableRewards() async {
    await Future.delayed(Duration(seconds: 1));
    return [
      Reward(
        id: '1',
        name: 'Sembako A',
        description: 'Minyak',
        imageUrl: 'assets/minyak.png',
        pointsRequired: 1000,
        isAvailable: true,
      ),
      Reward(
        id: '2',
        name: 'Sembako B',
        description: '5kg Beras',
        imageUrl: 'assets/beras5kg.jpeg',
        pointsRequired: 2000,
        isAvailable: true,
      ),
      Reward(
        id: '3',
        name: 'Sembako C',
        description: '5kg Beras',
        imageUrl: 'assets/beras5kg.jpeg',
        pointsRequired: 2000,
        isAvailable: true,
      ),
      Reward(
        id: '4',
        name: 'Sembako D',
        description: '5kg Beras',
        imageUrl: 'assets/beras5kg.jpeg',
        pointsRequired: 2000,
        isAvailable: true,
      ),
    ];
  }

  Future<String> redeemReward(String rewardId) async {
    await Future.delayed(Duration(seconds: 1));
    return _generateVoucherCode();
  }
}
