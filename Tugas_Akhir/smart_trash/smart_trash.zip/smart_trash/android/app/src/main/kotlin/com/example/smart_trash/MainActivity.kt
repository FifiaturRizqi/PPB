package com.example.smart_trash

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
